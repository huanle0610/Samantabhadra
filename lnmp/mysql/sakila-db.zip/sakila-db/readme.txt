D:\wamp\bin\mysql\mysql5.5.24\bin>mysql -uroot -p < C:\Users\hl\Desktop\sakila-db\sakila-db\sakila-schema.sql
Enter password: ******

D:\wamp\bin\mysql\mysql5.5.24\bin>mysql -uroot -p < C:\Users\hl\Desktop\sakila-db\sakila-db\sakila-data.sql
Enter password: ******


安装mysql-workbench(非必须，推荐)
http://cdn.mysql.com/Downloads/MySQLGUITools/mysql-workbench-community-6.3.6-winx64.msi
